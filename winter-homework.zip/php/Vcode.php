<?php
	require_once("./function.php");
	//require_once("./libs/Model/Vcode.class.php");
	if(!isset($_SESSION)){
    	
    	session_start();					//判断是否开启session；
	}
	
	//header("Content-type: image/jpeg");
	$img = M('Vcode');
	$img->create();

