<?php
	require_once('./libs/View/Display.class.php');
	require_once('function.php');
	$MB = M('MessageBoard');
	$method = $_POST['method'];
	switch ($method) {
		case 'create':
			$message = $_POST['text'];
			$videoname = $_POST['videoname'];
			$MB->create($message, $videoname);
			break;
		case 'add':
			$id = $_POST['id'];
			$MB->addSupport($id);
			break;
		case 'display':
			$videoname = $_POST['videoname'];
			$sql = $MB->display($videoname);
			$Display = new Display();
			$Display->displayMessageBoard($sql);
			break;
		default:
			echo "method false";
			break;
	}