<?php
	class DB{
		private static $db;
/**
 * 数据库函数
 * 
 */
		function __construct(){
			if(empty($this->db)){
				self::$db = $this->connect_db();
			}
		}

		function connect_db($dbname = "bb") {
			$db = mysqli_connect("localhost","root","",$dbname);
			if(mysqli_connect_errno($db)){
				echo"Failed to connect to MySQL: " . mysqli_connect_error();
				exit();
				return NULL;
			}
			else{
				$db->query("set names utf8");
				return $db;
			}
		}
		function query($sql){
			$result = self::$db->query($sql);
			return $result;
		}
	}
?>