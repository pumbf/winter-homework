<?php
	class Guanli{

 		/**
 		 * 得到显示的sql语句
 		 * @param  [string] $table [目标表]
 		 * @param  [string] $field [目标栏]
 		 * @param  [string] $value [目标数据]
 		 * @return [string] $sql    sql语句
 		 */
		function display($table, $field, $value){
			$SQL = new SQL($table, $field, $value);
			$sql = $SQL->select();
			if(empty($field)||empty($value)){
				return $sql." WHERE provider='".$_SESSION['username']."'";
			}else{
				return $sql." AND provider='".$_SESSION['username']."'";
			}
		}
		/**
		 * 删除数据库信息，文件，和留言表
		 * @param  [type] $id [目标对应的id]
		 * @return [type]     [description]
		 */
		function delete($id){
			$db = new DB();
			$SQL = new SQL('resource','id',$id);		//通过sql类获取sql语句
			$sql = $SQL->select();
			$result = $db->query($sql);
			$data = $result->fetch_assoc();
			$name = $data['videoname'];
			$sql = $SQL->delete();
			//echo $sql;
			$result = $db->query($sql);
			$sql = new SQL('messageboard','videoname',$name);
			$path = dirname(dirname(dirname(dirname(__FILE__))))."/video/".$id."/";
			$this->delDirAndFile("$path");


		}
		function delDirAndFile($dirName){
			//删除文件，while遍历文件
			if($handle = opendir("$dirName")){
				while(($item = readdir($handle)) !== false){
					if ( $item != "." && $item != ".." ) {  
  						if ( is_dir( "$dirName/$item" ) ) {  
   								$this->delDirAndFile( "$dirName/$item" );  
   						} else {  
   							if( unlink( "$dirName/$item" ) )echo "成功删除文件： $dirName/$item<br />\n";  
   							}  
				}
			}
			closedir( $handle );  
   			if( rmdir( $dirName ) )echo "成功删除目录： $dirName<br />\n";
			}
		}



}