<?php
/**
 	*file: vcode.php
	*验证码图片
	*SESSION['code']
 */

	class Vcode{
		private $_width;       			//验证码宽度
		private $_height;				//验证码长度
		private $_codeNumber;			//验证码字符个数
		private $_pixNum;				//验证码干扰像素点个数
		private $_lineNum;				//验证码干扰线条数
		private $_image;					//验证码图片
		private $_code;      			//验证码
		/**
		 * 初始方法用来实例化验证。
		 * @param  int $width      设置验证码图片的宽度，默认为100.
		 * @param  int $height     设置验证码图片的高度，默认为38.
		 * @param  int $codeNumber 设置验证码图片的字符个数，默认为4。
		 * @param  int $pixNum    设置验证码图片的干扰像素个数，默认为1000.
		 * @param  int $lineNum   设置验证码图片的干扰线条数，默认为30.
		 * @return picture             验证码。
		 */
		function __construct($width = 100, $height = 38, $codeNumber = 4, $pixNum = 500, $lineNum = 5) {
			$this->_width = $width;
			$this->_height = $height;
			$this->_codeNumber = $codeNumber;
			$this->_pixNum = $pixNum;
			$this->_lineNum = $lineNum;
			$this->_code = $this->createCode();
		}

		/**
		 * 将得到的字符向服务器session保存
		 * @return 图像
		 */
		function create(){
			$_SESSION['code'] = $this->_code;            //将验证码放入$_SESSION下标为‘code’内
			$this->outputPicture();
			$this->outputImage();
		}

		/**
		 * 创建验证码图片，并加入验证码字符和干扰元素
		 */
		private function outputPicture(){
			$img = imagecreate($this->_width, $this->_height);
			$backgroundColor = imagecolorallocate($img, rand(225,255), rand(225,255), rand(225,255));
			imagefill($img, 0, 0, $backgroundColor);
			$bordercolor = imagecolorallocate($img, 0, 0, 0);
			imagerectangle($img, 0, 0, $this->_width-1, $this->_height, $bordercolor);
			
			for($i = 0; $i < $this->_codeNumber; $i++){
				$fontColor = imagecolorallocate($img, rand(0,100), rand(0,100), rand(0,100));
				$fontsize = rand(4,5);
				$x = floor($this->_width/$this->_codeNumber)*$i+3;
				$y = rand(0,$this->_height-imagefontheight($fontsize));
				//$address = '../iconfont/VINERITC.TTF';
				imagechar($img, $fontsize, $x, $y, $this->_code[$i], $fontColor);
			}

			$this->_image = $img;
			
			for($i = 0; $i < $this->_lineNum; $i++){
				$linecolor = imagecolorallocate($img, rand(0,255), rand(0,255), rand(0,255));
				imageline($img, rand(0,$this->_width), rand(0,$this->_height), rand(0,$this->_width), rand(0,$this->_height), $linecolor);
			}
			
			for($i = 0; $i < $this->_pixNum;$i++){
				$pixColor = imagecolorallocate($img, rand(0,200), rand(0,200), rand(0,200));
				imagesetpixel($img, rand(1, $this->_width-1), rand(1,$this->_height-1), $pixColor);
			}
			

		}
		/**
		 * 生成用户指定个数的字符串，去除o0
		 * @return 字符串
		 */
		private function createCode(){
			$code = "";
			$words = "qwertyuipasdfghjklzxcvbnm123456789";
			for($i = 0; $i < $this->_codeNumber; $i++)
			{
				$code .= $words[rand(0,33)];
			}
			return $code;

		}
		/**
		 * 输出图像；
		 */
		private function outputImage(){
			header("Content-type: image/png");
			imagepng($this->_image);
		}

		/**
		 * 析构释放内存
		 */
		function __destruct(){
			imagedestroy($this->_image);
		}

	}


	
	// $img = new Vcode();
	// $img->create();
