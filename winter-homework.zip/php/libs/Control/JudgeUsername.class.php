<?php
/**
 * 判断用户名
 */
	class JudgeUsername{
		protected $username;	//用户名

		function __construct(){
			if(isset($_POST['username']) && empty($_POST['username'])){		//是否为空
		 			exit();
		 		}
		 	$this->username = addslashes($_POST['username']);
		}
		function is_exist(){
			$db = new DB();
			$sql = "SELECT * FROM users WHERE username=".$this->username;
			$result = $db->query($sql);
			$value = $result->fetch_assoc();
			if(empty($value)){
				echo 0; //存在判断错误
			}else{
				echo 1;//不存在判断正确 
			}
		}
	} 