<?php
		/**
		 * 验证码判断
		 */
		 class JudgeVcode
		 {
		 	private $_vcode;
		 	/**
		 	 * 
		 	 */
		 	function __construct()
		 	{
		 		if(isset($_POST['code']) && empty($_POST['code'])){
		 			echo 0;
		 			exit();
		 		}
		 		$this->_vcode = $_POST['code'];
		 	}
		 	function is_right(){
		 		if($this->_vcode == $_SESSION['code']){
		 			echo 1;      //判断正确
		 		}else{
		 			echo 0;     //判断错误
		 		}
		 	}
		 } 