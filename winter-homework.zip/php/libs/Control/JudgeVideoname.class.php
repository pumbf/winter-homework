<?php
	/**
	 * 判断视频名字
	 */
	class JudgeVideoname {
		protected $_videoname;

		function __construct(){
			if(isset($_POST['videoname']) && empty($_POST['videoname'])){
		 			exit();
		 		}
			$this->_videoname = addslashes($_POST['videoname']);
		}

		function is_exist(){
			$db = new DB();
			$sql = "SELECT * FROM resource WHERE videoname = '$this->_videoname'";
			$result = $db->query($sql);
			$value =$result->fetch_assoc();
			if(!empty($value)){
					echo 0;    //存在判断错误
			}else{
					echo 1;    //不存在，判断正确
			}
		}

	}
