<?php
	// $b = 0;
	// $Class_Control = array('JudgeUserId.class.php','JudgeVcode.class.php','LoginStatus.class.php' );
	// foreach ($Class_Control as $key => $value) {
	// 	require_once('./libs/Control/'.$value);
	// 	var_dump($a);
	// 	echo ++$b;

	// }
	// $Class_Model = array('DB.class.php','Enroll.class.php','Login.class.php','Vcode.class.php');
	// foreach ($Class_Model as $key => $value) {
	// 	$a = require_once('./libs/Model/'.$value);
	// 	var_dump($a);
	// 	echo ++$b;
	// }
	// $Class_View = array('');
	// if(!empty($Class_View)){
	// 	foreach ($Class_View as $key => $value){
	// 	require_once ("./libs/View/".$value);
	// 	echo ++$b;
	// 	}
	// }
	// echo $b;
	error_reporting(0);       //屏蔽错误
	date_default_timezone_set('PRC');
	header("content-type:text/html; charset = utf-8");
	if(!isset($_SESSION)){
    	
    	session_start();					//判断是否开启session；
	}

	function C($classname, $functionname){
		function __autoload($classname){
			$classpath = './libs/Control/'.$classname.'.class.php';
			if(file_exists($classpath)){
				require_once($classpath);
			}else{
				echo 'classfile'.$classpath.'not found';
			}
		} 
		eval('$obj = new '.$classname.'();');
		eval('$obj->'.$functionname.'();'); 
	}
	function V($classname){
		function __autoload($classname){
			$classpath = './libs/View/'.$classname.'.class.php';
			if(file_exists($classpath)){
				require_once($classpath);
			}else{
				echo 'classfile'.$classpath.'not found';
			}
		}
		eval('$obj = new '.$classname.'();');
		return $obj;
	}

	function M($classname){

		function __autoload($class){
			$classpath = './libs/Model/'.$class.'.class.php';
			if(file_exists($classpath)){
				$a = require_once($classpath);
				;
			}else{
				echo 'classfile'.$classpath.'not found';
			}
		}
		// return new Vcode;
		eval('$obj = new '.$classname.'();');
		return $obj;
	}
	