<?php
	require_once("./libs/Model/DB.class.php");
	require_once("./function.php");
	//$method = $_POST['method'];
	$classname = $_POST['classname'];
	$functionname = $_POST['functionname'];


	C($classname,$functionname);

