
		<?php
			//error_reporting(0);
			require_once('function.php');
			require_once('./libs/View/Display.class.php');
			$table = empty($_GET['table'])?'resource':$_GET['table'];
			$field = empty($_GET['field'])?'':$_GET['field'];
			$value = empty($_GET['value'])?'':$_GET['value'];
			$Guanli = M('Guanli');
			$sql = $Guanli->display($table, $field, $value);
			$display = new Display();
			$display->GuanLiVideo($sql);
	
				