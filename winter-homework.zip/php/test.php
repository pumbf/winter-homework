<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/videoGuanLi.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont1/iconfont.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont4/iconfont.css">
	<title></title>
</head>
<body>
<?php
	require_once('function.php');
	$search = M('Search');
	$table = empty($_GET['table'])?'resource':$_GET['table'];
	$filed = empty($_GET['filed'])?'videoname':$_GET['filed'];
	$keyword = empty($_GET['keyword'])?'':$_GET['keyword'];
	$request = empty($_GET['request'])?'':$_GET['request'];
	$sql = $search->getsql($table, $filed, $keyword, $request);
	echo $sql;
?>
</body>
</html>
