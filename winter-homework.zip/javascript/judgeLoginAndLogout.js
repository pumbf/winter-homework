var request = new XMLHttpRequest();
request.open("POST","../php/Control.php");
request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
var data = "classname=LoginStatus&functionname=is_login";
request.send(data);
request.onreadystatechange = function(){
	if(request.readyState === 4){	//请求是否完成
		if(request.status === 200){	//请求是否成功
			var result = request.responseText;
			if(result === '0'){ //不登录
			}else{
					var niCheng = document.querySelector(".niCheng");
					niCheng.innerHTML = result;
						$(document).ready(function(){
						$(".EL").hide();
						$(".ELOK").show();
	});
			}
		}else{
			alert("发生错误" + request.status);
		}
	}
};


// if (mark == 0) {
// 	$(document).ready(function(){
// 		$(".EL").show();
// 		$(".ELOK").hide();
// 	});
// };
$(document).ready(function(){
	$(".logout").click(function(){
		var request = new XMLHttpRequest();    //ajax
		request.open("POST","../php/Control.php");
		var data = "classname=LoginStatus&functionname=out_login";
		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		request.send(data);
		request.onreadystatechange = function(){//监听是否发生改变;
			if(request.readyState === 4){  //请求是否完成
				if(request.status === 200){  //请求是否成功
									//注销成功
					$(document).ready(function(){
						$(".EL").show();
						$(".ELOK").hide();
					})
				}else{
						alert("发生错误" + request.status);
				}
			}
		}
	})
})