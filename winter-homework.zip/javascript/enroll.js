var mark;
var findUserID = document.querySelector("#theFrom").userid;
var nameError = document.getElementById("errorName");        //错误提示框
var findName = document.getElementById("name");				//昵称输入框	
findUserID.onblur = function(){
	var changeAccount = document.querySelector("#errorAccount");
	var id = document.querySelector("#account").value;
	if (!(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(id))&&!(/^[1][3458]\d{9}$/.test(id))) {
		 if(id.length == 0){
			changeAccount.innerHTML  = "亲，请输入想注册的邮箱或手机号哦!";
		}else{
		changeAccount.innerHTML = "邮箱/手机号格式错误！";
		}
		mark=0;
	}else{
		var request = new XMLHttpRequest();    //ajax
				request.open("POST","../php/Control.php");
				var data = "classname=JudgeUserId&functionname=is_exist&userid="+ id;
				request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
				request.send(data);
				request.onreadystatechange = function(){		//监听是否发生改变;
					if(request.readyState === 4){  //请求是否完成
						if(request.status === 200){  //请求是否成功
							var result = request.responseText;
							if(result == '0'){		//不存在能用，存在不能用
								changeAccount.innerHTML = "这个账号已经存在了哦，换一个试试吧( ^_^ )";
								mark = 0;
							} else{
								changeAccount.innerHTML = "&nbsp";
								mark = 1;
							}   
						}else{
							alert("发生错误" + request.status);
						}
					}
				}
			
	}
	// alert(mark);
}

	findName.onblur = function(){
		if(findName.value.length>0){
			var request = new XMLHttpRequest();
			request.open("POST","../php/Control.php");
			request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			var data = "classname=JudgeUsername&functionname=is_exist&username=" + findName.value;
			request.send(data);
			request.onreadystatechange = function(){       			//监听是否发生改变;
				if(request.readyState === 4){  //请求是否完成
						if(request.status === 200){  //请求是否成功
							var result = request.responseText;
							nameError.innerHTML = result;
							 if (result == '0'){   //视频名字是否存在
							 	mark = 0;
							 	nameError.innerHTML = "该昵称已存在，请换一个更漂亮的名字";
							 }else{
							 	mark = 1;
							 	nameError.innerHTML = "&nbsp";
							 	
							 }
						}else{
							alert("发生错误" + request.status);
						}
					}
				}
		}else{
			nameError.innerHTML = "亲，请输入一个帅气的昵称";
		}
	}



function myFunction(){
	var gitUserId = findUserID.value;
	var findPassword1 = document.querySelector("#theFrom").userPassword1;
	var gitUserPassword1 = findPassword1.value;
	var findPassword2 = document.querySelector("#theFrom").userPassword2;
	var gitUserPassword2 = findPassword2.value;

	if (mark == 0) {
		return false;}
	if (gitUserId.length<1&&gitUserPassword1.length<1) {
		var changeAccount = document.querySelector("#errorAccount");
			changeAccount.innerHTML = "亲，请输入想注册的邮箱或手机号哦!";
		var changePassword1 = document.querySelector("#errorPassword1");
			changePassword1.innerHTML = "啊咧！账号没密码么？";
		return false;}
	if (gitUserId.length<1) {
		var changeAccount = document.querySelector("#errorAccount");
			changeAccount.innerHTML = "亲，请输入想注册的邮箱或手机号哦!";
		return false;}
	if(gitUserPassword1.length<1){
		var changePassword1 = document.querySelector("#errorPassword1");
			changePassword1.innerHTML = "啊咧！账号没密码么？";
		return false;}
	if (gitUserPassword1!=gitUserPassword2) {
		var changePassword2 = document.querySelector("#errorPassword2");
			changePassword2.innerHTML = "哎？第一次输入的密码与第二次不符哦！";
		return false;}
	else{
	document.querySelector("#theFrom").action = "../php/Enroll.php";
	document.querySelector("#theFrom").method = "POST";
	document.querySelector("#theFrom").submit();}
}


