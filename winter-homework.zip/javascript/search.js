var img = new Array();  //创建一个数组
var search = document.querySelector("#search");
search.onclick = function(){
	var keyword = document.querySelector('#keyword').value;
	var request = new XMLHttpRequest();
		request.open("GET","../php/Search.php?keyword="+keyword);
		request.send();
		request.onreadystatechange = function(){
			//监听是否发生改变;
			if(request.readyState === 4){  //请求是否完成
				if(request.status === 200){  //请求是否成功
					document.getElementById('displaySearch').innerHTML = request.responseText;
				}else{
					alert("发生错误" + request.status);
				}
			}
		}

}
function display(){
	var keyword = document.querySelector('#keyword').value;
	var request = new XMLHttpRequest();
		request.open("GET","../php/Search.php?keyword="+keyword);
		request.send();
		request.onreadystatechange = function(){
			//监听是否发生改变;
			if(request.readyState === 4){  //请求是否完成
				if(request.status === 200){  //请求是否成功
					document.getElementById('displaySearch').innerHTML = request.responseText;
				}else{
					alert("发生错误" + request.status);
				}
			}
		}
}
display();