/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50617
Source Host           : 127.0.0.1:3306
Source Database       : bb

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2016-03-05 20:39:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for messageboard
-- ----------------------------
DROP TABLE IF EXISTS `messageboard`;
CREATE TABLE `messageboard` (
  `id` smallint(3) unsigned NOT NULL AUTO_INCREMENT,
  `videoname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `time` datetime NOT NULL,
  `text` varchar(300) NOT NULL,
  `support` smallint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of messageboard
-- ----------------------------

-- ----------------------------
-- Table structure for resource
-- ----------------------------
DROP TABLE IF EXISTS `resource`;
CREATE TABLE `resource` (
  `id` int(5) NOT NULL COMMENT '标号',
  `variety` varchar(20) NOT NULL COMMENT '种类',
  `videoname` varchar(100) NOT NULL COMMENT '视频名字',
  `picture` varchar(100) DEFAULT NULL,
  `provider` varchar(50) NOT NULL COMMENT '视频上传者',
  `format` varchar(50) NOT NULL COMMENT '视频格式',
  `time` datetime(5) NOT NULL COMMENT '上传时间',
  `address` varchar(100) NOT NULL,
  `introduction` varchar(999) NOT NULL,
  `display` int(1) NOT NULL DEFAULT '0' COMMENT '0不在主页top显示，1~6按顺序显示',
  PRIMARY KEY (`id`,`videoname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of resource
-- ----------------------------
INSERT INTO `resource` VALUES ('1', '动画', 'fenbyC语言', '../video/1/image/small.jpg', '大帅比1', 'video/mp4', '2016-03-05 20:37:01.00000', '../video/1/fenbyC语言.mp4', '测试', '0');
INSERT INTO `resource` VALUES ('2', '动画', 'fenbyC语言1', '../video/2/image/small.jpg', '大帅比1', 'video/mp4', '2016-03-05 20:38:33.00000', '../video/2/fenbyC语言1.mp4', 'test', '0');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `userId` varchar(100) CHARACTER SET utf8 NOT NULL,
  `keyboard` varchar(32) CHARACTER SET utf8 NOT NULL,
  `username` varchar(100) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`,`userId`,`username`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('8', '12345678901', '111111', '大帅比');
INSERT INTO `users` VALUES ('9', '13100000000', '111111', '大帅比1');
INSERT INTO `users` VALUES ('10', '15525111111', '123456789', 'rabbit');
INSERT INTO `users` VALUES ('11', '13111111111', '123456789', '大帅111');
INSERT INTO `users` VALUES ('12', '13122222222', '123456789', '大帅111q');
INSERT INTO `users` VALUES ('13', '13333333333', '123456789', 'asdqweqwe');
