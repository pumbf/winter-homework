var request = new XMLHttpRequest();
request.open("POST","../php/Control.php");
request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
var data = "classname=LoginStatus&functionname=is_login";
request.send(data);
request.onreadystatechange = function(){
	if(request.readyState === 4){	//请求是否完成
		if(request.status === 200){	//请求是否成功
			var result = request.responseText;
			if(result === '0'){ //不登录
				window.location.href="login.html";
				alert("上传文件的话，要先登录哦");
			}else{
					var niCheng = document.querySelector(".niCheng");
					niCheng.innerHTML = result;
						$(document).ready(function(){
						$(".EL").hide();
						$(".ELOK").show();
	});
			}
		}else{
			alert("发生错误" + request.status);
		}
	}
};


// if (mark == 0) {
// 	$(document).ready(function(){
// 		$(".EL").show();
// 		$(".ELOK").hide();
// 	});
// };
$(document).ready(function(){
	$(".logout").click(function(){
		var request = new XMLHttpRequest();    //ajax
		request.open("POST","../php/Control.php");
		var data = "classname=LoginStatus&functionname=out_login";
		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		request.send(data);
		request.onreadystatechange = function(){//监听是否发生改变;
			if(request.readyState === 4){  //请求是否完成
				if(request.status === 200){  //请求是否成功
									//注销成功
					$(document).ready(function(){
						$(".EL").show();
						$(".ELOK").hide();
					})
				}else{
						alert("发生错误" + request.status);
				}
			}
		}
	})
})









var mark = 0;											//判断是否视频名字存在了
var biaoTi = document.getElementById("biaoTi");			//视频名字输入框
var biaoTiError = document.querySelector("#biaoTi_error"); //错误提示


document.addEventListener("change",function(){
	document.querySelector("#upText").value
	 = document.querySelector("#FILE").value;
});
// 文本框获取file选择的视频名称



var dongHua = document.querySelector("#dongHua");
	dongHua.addEventListener("mouseup",function_dongHua);
		function function_dongHua(){
			document.querySelector("#fenLei").value
			 = dongHua.innerHTML;
		};
var yinYue = document.querySelector("#yinYue");
	yinYue.addEventListener("mouseup",function_yinYue);
		function function_yinYue(){
			document.querySelector("#fenLei").value
			 = yinYue.innerHTML;
		};
var youXi = document.querySelector("#youXi");
	youXi.addEventListener("mouseup",function_youXi);
		function function_youXi(){
			document.querySelector("#fenLei").value
			 = youXi.innerHTML;
		};
var yuLe = document.querySelector("#yuLe");
	yuLe.addEventListener("mouseup",function_yuLe);
		function function_yuLe(){
			document.querySelector("#fenLei").value
			 = yuLe.innerHTML;
		};
var dianShiJu = document.querySelector("#dianShiJu");
	dianShiJu.addEventListener("mouseup",function_dianShiJu);
		function function_dianShiJu(){
			document.querySelector("#fenLei").value
			 = dianShiJu.innerHTML;
		};
var fanJu = document.querySelector("#fanJu");
	fanJu.addEventListener("mouseup",function_fanJu);
		function function_fanJu(){
			document.querySelector("#fenLei").value
			 = fanJu.innerHTML;
		};
var dianYin = document.querySelector("#dianYin");
	dianYin.addEventListener("mouseup",function_dianYin);
		function function_dianYin(){
			document.querySelector("#fenLei").value
			 = dianYin.innerHTML;
		};
var wuDao = document.querySelector("#wuDao");
	wuDao.addEventListener("mouseup",function_wuDao);
		function function_wuDao(){
			document.querySelector("#fenLei").value
			 = wuDao.innerHTML;
		};

function function_up()
{
	var file_value = document.querySelector("#FILE").value;
	var fenLei_value = document.querySelector("#fenLei").value;
	var biaoTi_value =  document.querySelector("#biaoTi").value;
	var jianJie_value =  document.querySelector("#jianJie").value;
	var error = new Array();
	error[0] = file_value.length;
	error[1] = fenLei_value.length;
	error[2] = biaoTi_value.length;
	error[3] = jianJie_value.length;
	for(var i=0;i<error.length;i++)
	{
		if (error[i]<1)
		{
			if (error[0]<1)
			{
				var upButton_error = document.querySelector("#upButton_error");
				upButton_error.innerHTML = "请添加视频源信息！";
			}else{
					var upButton_error = document.querySelector("#upButton_error");
					upButton_error.innerHTML = "";
				}
			if (error[1]<1)
			{
				var upButton_error = document.querySelector("#fenLei_error");
				upButton_error.innerHTML = "请在分区中选择投稿类型！";
			}else{
					var upButton_error = document.querySelector("#fenLei_error");
					upButton_error.innerHTML = "";
				}
			if (error[2]<1)
			{
				var upButton_error = document.querySelector("#biaoTi_error");
				upButton_error.innerHTML = "标题不能为空！";
			}else{
					var upButton_error = document.querySelector("#biaoTi_error");
				upButton_error.innerHTML = "";
				}
			if (error[3]<1)
			{
				var upButton_error = document.querySelector("#jianJie_error");
				upButton_error.innerHTML = "请填写简历！";
			}else{
					var upButton_error = document.querySelector("#jianJie_error");
				upButton_error.innerHTML = "";
				}
			return false;
		}
	}
	if(mark != 1){
		return false;
	}
	document.querySelector("#theFrom").method = 'POST';
	document.querySelector("#theFrom").action ='../php/Classify.php';
	document.querySelector("#theFrom").submit();
}


	biaoTi.onblur = function(){
		if(biaoTi.value.length>0){
			var request = new XMLHttpRequest();
			request.open("POST","../php/Control.php");
			var data = "classname=JudgeVideoname&functionname=is_exist&videoname=" + biaoTi.value;
			request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			request.send(data);
			request.onreadystatechange = function(){       			//监听是否发生改变;
				if(request.readyState === 4){  //请求是否完成
						if(request.status === 200){  //请求是否成功
							var result = request.responseText;
							 if (result == '1'){   //视频名字是否存在
							 	mark = 1;
							 	biaoTiError.innerHTML ="&nbsp";
							 }else{
							 	biaoTiError.innerHTML = "该视频的名字已存在，请换一个更漂亮的名字";
							 }
						}else{
							alert("发生错误" + request.status);
						}
					}
				}
		}else{
			biaoTiError.innerHTML = "标题不能为空！";
		}
	}

