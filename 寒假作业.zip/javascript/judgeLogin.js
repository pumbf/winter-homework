var mark = 0;
var request = new XMLHttpRequest();
request.open("POST","../php/Control.php");
request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
var data = "classname=LoginStatus&functionname=is_login";
request.send(data);
request.onreadystatechange = function(){
	if(request.readyState === 4){	//请求是否完成
		if(request.status === 200){	//请求是否成功
			var result = request.responseText;
			if(result === '0'){ //不登录

			}else{
				mark = 1;
			}
		}else{
			alert("发生错误" + request.status);
		}
	}
}