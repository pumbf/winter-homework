function ajax(method){
	var a = document.getElementById("method");
	a.onfocus = function(){
		a.onblur = function(){
			if(a.value.length>1){
				var request = new XMLHttpRequest();
				request.open("GET","../php/login.class.php?value=" 
					+ document.getElementById("method").value 
					+ '&method=' + method);
				request.send();
				request.onreadystatechange = function(){
					//监听是否发生改变;
					if(request.readyState === 4){  //请求是否完成
						if(request.status === 200){  //请求是否成功
							var result = parseInt(request.responseText);
							switch(result){
								case 0: document.querySelector("#errorAccount").innerHTML = "亲，你的账号已被注册喔！";
								break;
								case 1: document.querySelector("#errorAccount").innerHTML = "亲，该账号可以使用喔！";
								break;
								case 2:  document.querySelector("#errorVcode").innerHTML = "验证码正确";
								break;
								case 3:  document.querySelector("#errorVcode").innerHTML = "验证码错误";
								break;
								default:
								document.querySelector("#errorAccount").innerHTML = "服务器故障";
							}

						}else{
							return false;
							//alert("发生错误" + request.status);
						}
					}else{
						return false;
					}
				}else{
					return false;
				}
			}
		}
	}
}

var go = ajax(account);
var went = ajax(vcode);