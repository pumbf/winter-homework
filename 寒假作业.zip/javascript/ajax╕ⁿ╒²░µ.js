// function judgeVcode(){
// 	var obj = document.getElementById("");      //监听的对话框
// 	obj.onfocus = function(){
// 		if(a.value.length>0){
// 			obj.onblur = function(){
// 				var request = new XMLHttpRequest();    //ajax
// 				request.open("POST","../php/Control.php");
// 				var data = "classname=JudgeVcode&functionname=is_right&code="+ obj.value;
// 				request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
// 				request.send(data);
// 				request.onreadystatechange = function(){
// 				//监听是否发生改变;
// 					if(request.readyState === 4){  //请求是否完成
// 						if(request.status === 200){  //请求是否成功
// 							var result = request.responseText;
// 							return result == '1'?ture:false;   //验证码是否正确
// 						}else{
// 							alert("发生错误" + request.status);
// 						}
// 					}
// 				}
// 			}
// 		}
// 	}
// }








function judgeLogin(){
	//var obj = document.getElementById("");      //监听的对话框
	//obj.onclick = function(){
		var request = new XMLHttpRequest();    //ajax
		request.open("POST","../php/Control.php");
		var data = "classname=JudgeStatus&functionname=is_login";
		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		request.send(data);
		request.onreadystatechange = function(){//监听是否发生改变;
			if(request.readyState === 4){  //请求是否完成
				if(request.status === 200){  //请求是否成功
					var result = request.responseText;
					return result == '1';  //ture：登录了，false:没登录
				}else{
						alert("发生错误" + request.status);
				}
			}
		}
	}
}


function outLogin(){
	var obj = document.getElementById("");      //监听的对话框
	obj.onclick = function(){
		var request = new XMLHttpRequest();    //ajax
		request.open("POST","../php/Control.php");
		var data = "classname = JudgeStatus&functionname=out_login";
		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		request.send(data);
		request.onreadystatechange = function(){//监听是否发生改变;
			if(request.readyState === 4){  //请求是否完成
				if(request.status === 200){  //请求是否成功
									//注销成功
				}else{
						alert("发生错误" + request.status);
				}
			}
		}
	}
}

	