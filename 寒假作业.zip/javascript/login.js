function change() {
		var a = document.getElementById('vcode');
		a.src='../php/Vcode.php?'+ Math.random();
	}

var acc = document.querySelector("#account");
	acc.addEventListener("click",cut1);
	function cut1(){
		var errorAcc = document.querySelector("#errorAccount");
			errorAcc.innerHTML = "&nbsp;";
	}
var pass = document.querySelector("#password");
	pass.addEventListener("click",cut2);
	function cut2(){
		var errorpass = document.querySelector("#errorPassword");
			errorpass.innerHTML = "&nbsp;";
	}
var obj = document.querySelector("#captcha");
	obj.addEventListener("click",cut3);
	function cut3(){
		var errorVcode = document.querySelector("#errorCaptcha");
			errorVcode.innerHTML = "&nbsp;";
	}

var judge = 0;
var obj = document.getElementById("captcha");
obj.onblur = function(){
	var request = new XMLHttpRequest();    //ajax
	request.open("POST","../php/Control.php");
	var data = "classname=JudgeVcode&functionname=is_right&code="+ obj.value;
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	request.send(data);
	request.onreadystatechange = function(){	//监听是否发生改变;
		if(request.readyState === 4){  //请求是否完成
			if(request.status === 200){  //请求是否成功
				var result = request.responseText;
				if(result=="1"){
					var errorVcode = document.querySelector("#errorCaptcha");
						errorVcode.innerHTML = "验证码输入正确,d=(^▽^*)b";
						 judge = 1 ;  //验证码是否正确
				}else{
					judge = 0;
					if (obj.value.length<1) {
						var errorVcode = document.querySelector("#errorCaptcha");
							errorVcode.innerHTML = "请输入验证码！";
					}else{
						var errorVcode = document.querySelector("#errorCaptcha");
							errorVcode.innerHTML = "验证码错误！";
					}
				}
				
			}else{
				alert("发生错误" + request.status);
			}	
		}
	}
}

function myFunction(){
	var findUserID = document.querySelector("#theFrom").userid;
	var gitUserId = findUserID.value;
	var findUserPassword = document.querySelector("#theFrom").userPassword;
	var gitUserPassword = findUserPassword.value;
	      //监听的对话框

	// var request = new XMLHttpRequest();    //ajax
	// request.open("POST","../php/Control.php");
	// var data = "classname=JudgeVcode&functionname=is_right&code="+ obj.value;
	// request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	// request.send(data);
	// request.onreadystatechange = function(){	//监听是否发生改变;
	// 	if(request.readyState === 4){  //请求是否完成
	// 		if(request.status === 200){  //请求是否成功
	// 			var result = request.responseText;
	// 			if(result=="1"){
	// 				var errorVcode = document.querySelector("#errorCaptcha");
	// 					errorVcode.innerHTML = "验证码输入正确,d=(^▽^*)b";
	// 					 judge = 1 ;  //验证码是否正确
	// 			}else{
	// 				judge = 0;
	// 				if (obj.value.length<1) {
	// 					var errorVcode = document.querySelector("#errorCaptcha");
	// 						errorVcode.innerHTML = "请输入验证码！";
	// 				}else{
	// 					var errorVcode = document.querySelector("#errorCaptcha");
	// 						errorVcode.innerHTML = "验证码错误！";
	// 				}
	// 			}
				
	// 		}else{
	// 			alert("发生错误" + request.status);
	// 		}	
	// 	}
	// }

	if (judge != 1) {
		return false
	}
	if (gitUserId.length<1&gitUserPassword.length<1) {
		var changeAccount = document.querySelector("#errorAccount");
			changeAccount.innerHTML = "亲，请输入注册时的邮箱或手机号啦!";
		var changePassword = document.querySelector("#errorPassword");
			changePassword.innerHTML = "嚯呀，你没输密码么？";
		return false;}
	if (gitUserId.length<1) {
		var changeAccount = document.querySelector("#errorAccount");
			changeAccount.innerHTML = "亲，请输入注册时的邮箱或手机号啦!";
		return false;}
	if(gitUserPassword.length<1){
		var changePassword = document.querySelector("#errorPassword");
			changePassword.innerHTML = "嚯呀，你没输密码么？";
		return false;}
	else{
		
	document.querySelector("#theFrom").action = "../php/Login.php";
	document.querySelector("#theFrom").method = "POST";
	document.querySelector("#theFrom").submit();
	}



	// var request = new XMLHttpRequest();    //ajax
	// request.open("POST","../php/Control.php");
	// var data = "classname=JudgeStatus&functionname=is_login";
	// request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	// request.send(data);
	// request.onreadystatechange = function(){//监听是否发生改变;
	// 	if(request.readyState === 4){  //请求是否完成
	// 		if(request.status === 200){  //请求是否成功
	// 			var result = request.responseText;
	// 			if (result == "1") {
	// 				var EL = document.querySelector(".EL");
	// 				var ELOK = document.querySelector(".ELOK");
	// 				EL.style.display = "none";
	// 				ELOK.style.display = "block";
	// 			}
	// 			return result == '1';  //ture：登录了，false:没登录
	// 		}else{
	// 				alert("发生错误" + request.status);
	// 		}
	// 	}
	// }

var mark = 0;
var request = new XMLHttpRequest();
request.open("POST","../php/Control.php");
var data = "classname=LoginStatus&functionname=is_login";
request.send(data);
request.onreadystatechange = function(){
	if(request.readyState === 4){	//请求是否完成
		if(request.status === 200){	//请求是否成功
			var result = request.responseText;
			if(result === '0'){ //不登录

			}else{
				mark = 1;
			}
		}else{
			alert("发生错误" + request.status);
		}
	}
}
if (mark == 1) {
	$(document).ready(function(){
		$(".EL").hide();
		$(".ELOK").show();
	});
};




}