$.fn.autoHeight = function(){
	
	function autoHeight(elem){
		elem.style.height = 'auto';
		elem.scrollTop = 0; //防抖动
		elem.style.height = elem.scrollHeight + 'px';
	}
	
	this.each(function(){
		autoHeight(this);
		$(this).on('keyup', function(){
			autoHeight(this);
		});
	});
 
}
	
	
$('textarea[autoHeight]').autoHeight();

var request = new XMLHttpRequest();
request.open("POST","../php/Control.php");
request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
var data = "classname=LoginStatus&functionname=is_login";
request.send(data);
request.onreadystatechange = function(){
	if(request.readyState === 4){	//请求是否完成
		if(request.status === 200){	//请求是否成功
			var result = request.responseText;
			if(result === '0'){ //不登录
			}else{
					var niCheng = document.querySelector(".niCheng");
					niCheng.innerHTML = result;
					//var ansewer_userId = document.querySelector(".ansewer_userId");
					//ansewer_userId.innerHTML = result;  //回复的昵称显示
						$(document).ready(function(){
						$(".EL").hide();
						$(".ELOK").show();

						$(".prompt").hide();
						$(".message").show();
						$(".fa_biao").show();
						$(".dan_mu_judge").hide();
						$(".dan_mu").show();
	});
			}
		}else{
			alert("发生错误" + request.status);
		}
	}
};

$(document).ready(function(){
	$(".logout").click(function(){
		var request = new XMLHttpRequest();    //ajax
		request.open("POST","../php/Control.php");
		var data = "classname=LoginStatus&functionname=out_login";
		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		request.send(data);
		request.onreadystatechange = function(){//监听是否发生改变;
			if(request.readyState === 4){  //请求是否完成
				if(request.status === 200){  //请求是否成功
									//注销成功
					$(document).ready(function(){
						$(".EL").show();
						$(".ELOK").hide();



						$(".prompt").show();
						$(".message").hide();
						$(".fa_biao").hide();
						$(".dan_mu_judge").show();
						$(".dan_mu").hide();
					})
				}else{
						alert("发生错误" + request.status);
				}
			}
		}
	})
})

var fa_biao = document.querySelector(".fa_biao");
fa_biao.onmouseup = function(){
	
	document.querySelector(".answer_content").value = document.querySelector(".message").value;
	document.querySelector(".message").value = "";
}


$(document).ready(function(){
	$(".dan_mu_export").click(function(){
		$(".qwe").show();
		document.querySelector(".dan_mu_box").innerText  = document.querySelector(".dan_mu_imput").value;
		var text = $(".dan_mu_imput").val();
		if(text == ""){
			return;
		};
		var danmu1 = $("<div style='right:20px;top:0px;opacity:1color:"+color1()+";'>"+text+"<div>");
		$(".qwe").append(danmu1.show());
		document.querySelector(".dan_mu_imput").value = "";
		init_barrshe();
	})

	function init_barrshe(){
		var top1 = 0;
		$(".qwe div").show().each(function(){
			var left1 = $(".qwe").width()-$(this).width();
			var height1 = $(".qwe").height();
			top1 +=15;
			if (top1 >= (height1 -30)){
				top1 = 0;
			}
			$(this).css({left:left1,top:top1,color:color1()});
			var time = 5000;
			if ($(this).index() % 2 == 0){
				time = 10000;
			}
			$(this).animate({left:0},time,function(){
				$(this).remove();
			})
		})
	}



	function color1(){
	return '#' + (function(h){
	return new Array(7 - h.length).join("0") + h
	}
	)((Math.random() * 0x1000000 << 0).toString(16))
}
});
var value;
var textvalue = document.getElementById('text');
textvalue.onblur = function(){
	value = textvalue.value;
}
function create(){
	//alert(value);
	 var videoname = document.getElementById('name').value;
	 var request = new XMLHttpRequest();
	 request.open("POST","../php/MessageBoard.php");
	 var data = "videoname=" + videoname +"&text=" + value + "&method=create";
	 request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 request.send(data);
	 request.onreadystatechange = function(){
	 	if(request.readyState === 4){
	 		if(request.status === 200){
	 			request.open("POST","../php/MessageBoard.php");
	 			request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 			data = "videoname=" + videoname + "&method=display";
	 			request.send(data);
	 			request.onreadystatechange = function(){
	 				if(request.readyState === 4){
	 					if(request.status === 200){
	 						var result = request.responseText;
	 						document.getElementById('answerBox').innerHTML = result;
	 					}
	 				}
	 			}
	 		}
	 	}
	 }

}
function addSupport(obj){
	var id = obj.id;
	var videoname = document.getElementById('name').value;
	 var request = new XMLHttpRequest();
	 request.open("POST","../php/MessageBoard.php");
	 var data = "id=" + id +"&method=add";
	 request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 request.send(data);
	 request.onreadystatechange = function(){
	 	if(request.readyState === 4){
	 		if(request.status === 200){
	 			request.open("POST","../php/MessageBoard.php");
	 			 request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 			data = "videoname=" + videoname + "&method=display";
	 			request.send(data);
	 			request.onreadystatechange = function(){
	 				if(request.readyState === 4){
	 					if(request.status === 200){
	 						var result = request.responseText;
	 						document.getElementById('answerBox').innerHTML = result;
	 					}
	 				}
	 			}
	 		}
	 	}
	 }

}
function display(){
	var videoname = document.getElementById('name').value;
	 var request = new XMLHttpRequest();
	 request.open("POST","../php/MessageBoard.php");
	 var data = "videoname=" + videoname + "&method=display";
	 request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	 request.send(data);
	 request.onreadystatechange = function(){
	 	if(request.readyState === 4){
	 		if(request.status === 200){
	 			var result = request.responseText;
	 			document.getElementById('answerBox').innerHTML = result;
	 		}
	 	}
	 }
}
display();

