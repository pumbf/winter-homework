var dongHua = document.querySelector("#dongHua");
	dongHua.addEventListener("mouseup",function_dongHua);
		function function_dongHua(){
			document.querySelector("#display").innerHTML
			 = dongHua.innerHTML;
		};
var yinYue = document.querySelector("#yinYue");
	yinYue.addEventListener("mouseup",function_yinYue);
		function function_yinYue(){
			document.querySelector("#display").innerHTML
			 = yinYue.innerHTML;
		};
var youXi = document.querySelector("#youXi");
	youXi.addEventListener("mouseup",function_youXi);
		function function_youXi(){
			document.querySelector("#display").innerHTML
			 = youXi.innerHTML;
		};
var yuLe = document.querySelector("#yuLe");
	yuLe.addEventListener("mouseup",function_yuLe);
		function function_yuLe(){
			document.querySelector("#display").innerHTML
			 = yuLe.innerHTML;
		};
var dianShiJu = document.querySelector("#dianShiJu");
	dianShiJu.addEventListener("mouseup",function_dianShiJu);
		function function_dianShiJu(){
			document.querySelector("#display").innerHTML
			 = dianShiJu.innerHTML;
		};
var fanJu = document.querySelector("#fanJu");
	fanJu.addEventListener("mouseup",function_fanJu);
		function function_fanJu(){
			document.querySelector("#display").innerHTML
			 = fanJu.innerHTML;
		};
var dianYin = document.querySelector("#dianYin");
	dianYin.addEventListener("mouseup",function_dianYin);
		function function_dianYin(){
			document.querySelector("#display").innerHTML
			 = dianYin.innerHTML;
		};
var wuDao = document.querySelector("#wuDao");
	wuDao.addEventListener("mouseup",function_wuDao);
		function function_wuDao(){
			document.querySelector("#display").innerHTML
			 = wuDao.innerHTML;
		};


var edit = document.querySelector("#edit");
var finish = document.querySelector("#finish");
var display_content = document.querySelector(".display_content");

$(document).ready(function(){
	$("#edit").click(function(){
		$("#edit").hide();
		$("#finish").show();
		$(".iconfont").show();
		$(".estop").show()
	});
});
$(document).ready(function(){
	$("#finish").click(function(){
		$("#edit").show();
		$("#finish").hide();
		$(".iconfont").hide();
		$(".estop").hide()
	});
});



$(".iconfont").click(function(){  //点击垃圾桶就提交from
	$("#manage").submit();
})
var play = 0;
function display(){
		var request1 = new XMLHttpRequest();
		request1.open("GET","../php/Guanlidisplay.php");
		request1.send();
		request1.onreadystatechange = function(){
			//监听是否发生改变;
			if(request1.readyState === 4){  //请求是否完成
				if(request1.status === 200){  //请求是否成功
					document.getElementById('displayVideo').innerHTML = request1.responseText;
				}else{
					alert("发生错误" + request1.status);
				}
			}
		}
}
display();



	function deleteVideo(obj){
		var id = obj.id;
		var request = new XMLHttpRequest();
		request.open("POST","../php/GuanliDelete.php")
		var data = "videoId=" + id;
		request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		request.send(data);
		request.onreadystatechange = function(){
			if(request.readyState === 4){	//请求是否完成
				if(request.status === 200){	//请求是否成功
					var request1 = new XMLHttpRequest();
					request1.open("GET","../php/Guanlidisplay.php");
					request1.send();
					request1.onreadystatechange = function(){
						//监听是否发生改变;
						if(request1.readyState === 4){  //请求是否完成
							if(request1.status === 200){  //请求是否成功
								document.getElementById('displayVideo').innerHTML = request1.responseText;
								$(".iconfont").show();
							}else{
								alert("发生错误" + request1.status);
							}
						}
					}
				}else{
					alert("发生错误" + request.status);
				}
			}
		}
	}



function getVariety(obj){
	var value = obj.innerHTML;
	var request1 = new XMLHttpRequest();
	request1.open("GET","../php/Guanlidisplay.php?table=resource&field=variety&value="+ value);
	request1.send();
	request1.onreadystatechange = function(){//监听是否发生改变;
		if(request1.readyState === 4){  //请求是否完成
			if(request1.status === 200){  //请求是否成功
				document.getElementById('displayVideo').innerHTML = request1.responseText;
			}else{
				lert("发生错误" + request1.status);
			}
		}
	}
}

// document.querySelector("#display").onreadystatechange = function(){
// 	display();
// }