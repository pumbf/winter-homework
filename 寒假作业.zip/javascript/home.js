var search = document.querySelector('#search');
search.onclick = function(){
	var keyword = document.querySelector('#keyword').value;
		window.open('./Search.php?keword='+keyword);
}

function display(){
	var request = new XMLHttpRequest();
		request.open("GET","../php/topDisplay.php");
		request.send();
		request.onreadystatechange = function(){
			//监听是否发生改变;
			if(request.readyState === 4){  //请求是否完成
				if(request.status === 200){  //请求是否成功
					document.getElementById('topdisplay').innerHTML = request.responseText;
				}else{
					alert("发生错误" + request.status);
				}
			}
		}
}
display();
function displayClassify(a,id){
	var request = new XMLHttpRequest();
		request.open("GET","../php/displayClassify.php?classify=" + a);
		request.send();
		request.onreadystatechange = function(){
			//监听是否发生改变;
			if(request.readyState === 4){  //请求是否完成
				if(request.status === 200){  //请求是否成功
					document.getElementById(id).innerHTML = request.responseText;
				}else{
					alert("发生错误" + request.status);
				}
			}
		}
}
displayClassify('动画','donghua');
displayClassify('音乐','music');
displayClassify('游戏','game');
displayClassify('娱乐','yule');
displayClassify('番剧','dianshi');
displayClassify('影视剧','yingshiju');
displayClassify('电影','film');
displayClassify('舞蹈','dance');



