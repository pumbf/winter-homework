<?php
	require_once('function.php');
	$Guanli = M('Guanli');
	$Guanli->delete($_POST['videoId']);