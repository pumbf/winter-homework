<?php
	require_once("function.php");
	require_once("libs/View/Display.class.php");
	$search = M('Search');
	$table = empty($_GET['table'])?'resource':$_GET['table'];
	$filed = empty($_GET['filed'])?'videoname':$_GET['filed'];
	$keyword = empty($_GET['keyword'])?'':$_GET['keyword'];
	$request = empty($_GET['request'])?'':$_GET['request'];
	$sql = $search->getsql($table, $filed, $keyword, $request);
	$display = new Display();
	$display->displaySearch($sql,$keyword); 