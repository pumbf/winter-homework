<?php
	require_once('function.php');
	require_once('libs/View/Display.class.php');
	$db = M('DB');
	$Display = new Display();
	$Display->displayHomeTop();

