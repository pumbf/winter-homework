<?php
/**
 * 页面显示
 */
 class Display{
 
	function dealingTime($time){
		$date = explode('.', $time);
		return $date['0'];
	}

	function GuanLiVideo($sql){
		$db = new DB();						//连接数据库
		$result = $db->query($sql);	
		if(!$result){		//执行搜索
			echo "请先上传视频，才能加载喔！";
		}
		$row = $result->num_rows;			//搜索结果行数
		for($i = 0; $i < $row; $i++){
			$data = $result->fetch_assoc();
			$id= $data['id'];
			$picturepath = $data['picture'];
			$title = $data['videoname'];
			$introduction = $data['introduction'];
			$time ="上传时间：". $this->dealingTime($data['time']);
			$variety = '类别：'.$data['variety'];		
			echo"<div  class='display_video'>";
		    echo"<div class='iconfont' id='$id' onclick='deleteVideo(this)'>&#xe636;</div>";
			echo'<div class="estop"></div>';
			echo"<div id='img' class='display_img'><img src='$picturepath' width=160 height=100></div>";
			echo'<ul class="display_content">';
			echo"<input type='text' id='tiaoTi' class='content_tiaoti' name='videoname' readonly='readonly' value='$title'>";
			echo"<input type='text' id='tiaoTi' class='content_tiaoti' name='videovarity' readonly='readonly' value='$variety'>";
			echo"<input type='text' id='tiaoTi' class='content_tiaoti' name='time' readonly='readonly' value='$time'>";
			echo"<hr/>";
			echo"<textarea id='jianJie' name='introduction' readonly='readonly' class='jian_jie'>$introduction</textarea>";
			echo'</ul>';
			echo'</div>';

		} 
 	}

 	function displaySearch($sql,$keyword){
 		$db = new DB();
 		$result = $db->query($sql);
 		$row = $result->num_rows;
 		for($i = 0; $i < $row; $i++){
 			$data = $result->fetch_assoc();
 			$title = $data['videoname'];
 			$provider = $data['provider'];
 			$time = $this->dealingTime($data['time']);
 			$picturepath = $data['picture'];
 			$variety = $data['variety'];
 			$id = $data['id'];
 			if(!empty($keyword)){
 			$title = str_replace("$keyword", "<span style='font-weight: bold;color: #F00;'>$keyword</span>",$title);
 			}

 			echo"<a class='video_img' href='play.php?videoid=$id'>";
	 			echo"<div class='img'><img src='$picturepath' width=160 height=100 ></div>";
				echo"<div class='content'>";
					echo"<div class='biao_ti'>$title</div>";
					echo"<input type='text' class='time' readonly='readonly' value='$time'>";
					echo"<i class='iconfont' id='time_img'>&#xe613;</i>";
					echo"<div class='ni_cheng'>$provider</div>";
					echo"<input type='text' class='type' readonly='readonly' value='$variety'>";
					echo"<i class='iconfont' id='type_img'>&#xe62a;</i>";
				echo"</div>";
			echo"</a>";	
 		}
 	}


 	function displayMessageBoard($sql){
 		$db = new DB();
 		$result = $db->query($sql);
 		$row = $result->num_rows;
 		if(empty($row)){
 			echo "<h3>还没有人评论，快来评论吧！<h3/>";
 		}else{
	 		for($i = 0; $i < $row; $i++){
	 			$data = $result->fetch_assoc();
	 			$id = $data['id'];
	 			$username = $data['username'];
	 			$time = $this->dealingTime($data['time']);
	 			$text = $data['text'];
	 			$support = $data['support'];
	 				echo "<div class='answerBox' id='answerBox'>";
					echo"<em><div class='ansewer_userId'>$username</div></em>";
					echo"<div><textarea class='answer_content' autoHeight='ture' readonly='readonly'>$text</textarea></div>";
					echo"<em><div class='answer_time'>$time</div></em>";
					echo"<div class='good' id='$id' onclick='addSupport(this)'><span>赞</span><span class='number'>($support)</span></div>";
					echo "</div>";
	 		}
 		}
 	}
 	function displayHomeTop(){
 		$db = new DB();
 		$order;
 		for($order = 1; $order <= 6 ; $order++){
 			$SQL = new SQL('resource', 'display', $order);
 			$sql = $SQL->select();
 			$result = $db->query($sql);
 			$data = $result->fetch_assoc();
 			$mark = ($order >3)  ? 2:1;
 			if(empty($data)){
 				$d = $order+6;
	 			echo"<a class='play_picture$mark' href='home.html'>";
					echo"<div class='picture_a'><img src='../img/$d.jpg' height=100 width=160></div>";
					echo"<div class='play_title'>无资源</div>";
				echo"</a>";
 			}else{
 				$name = $data['videoname'];
	 			$picture = $data['picture'];
	 			$id = $data['id'];
	 			echo "<a class='play_picture$mark' href='play.php?videoid=$id'>";
				echo "<div class='picture_a'><img src='$picture' height=100 width=160></div>";
				echo "<div class='play_title'>$name</div>";
				echo "</a>";
			}
 		}

 	}


 	function displayHomeClassify($sql){
 		$db = new DB();
 		$number++;
 		$result = $db->query($sql);
 		$row = $result->num_rows;
 		for($i=1;$i<=5;$i++){
 			if($i<=$row){
	 			$data = $result->fetch_assoc();
	 			$name = $data['videoname'];
	 			$picture = $data['picture'];
	 			$id = $data['id'];
	 			echo"<a class='spread_content' href='play.php?videoid=$id'>";
					echo"<div class='spread_img'><img src='$picture' height=100 width=160></div>";
					echo"<div class='spread_title'>$name</div>";
				echo"</a>";
			}else{
				echo"<a class='spread_content' href='home.html'>";
					echo"<div class='spread_img'><img src='../img/$i.jpg' height=100 width=160></div>";
					echo"<div class='spread_title'>无资源</div>";
				echo"</a>";
			}
 		}
 		// foreach ($result as $key => $data) {
 		// 	$number = 
 		// 	$name = $data['videoname'];
 		// 	$picture = $data['picture'];
 		// 	$id = $data['id'];
 		// 	echo"<a class='spread_content' href='play.php?videoid=$id'>";
			// 	echo"<div class='spread_img'><img src='$picture' height=100 width=160></div>";
			// 	echo"<div class='spread_title'>$name</div>";
			// echo"</a>";
 		// }
 	}
}