<?php
	class LoginStatus {
		function is_login(){
			if(empty($_SESSION['username'] || isset($_SESSION['username']))) {

				echo 0;     //未登录
			}else{
				echo $_SESSION['username'];   //已登录
			}
		}

		function out_login(){
			$_SESSION['username'] = NULL;
		}
	}
