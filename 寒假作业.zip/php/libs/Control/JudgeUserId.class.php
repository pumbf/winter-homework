<?php
	/**
	* 判断用户账号
	*/
	class JudgeUserId 
	{
		protected $userId;
		/**
		 * 
		 * @param [type] $userId [用户名信息]
		 */
		function __construct(){
			if(isset($_POST['useid']) && empty($_POST['userid'])){		//是否为空
		 			exit();
		 		}
			$this->userId = addslashes($_POST['userid']);
		}

		function is_exist(){
			$db = new DB();
			$sql = "SELECT * FROM users WHERE userId = '$this->userId'";	//sql语句判断是否存在该信息
			$result = $db->query($sql);
			$value = $result->fetch_assoc();
			if($value){
					echo 0;    //存在判断错误
			}else{
					echo 1;    //不存在，判断正确
			}
		}
	}