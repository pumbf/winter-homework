<?php
	/**
	* 登录页面
	*/
	class Login 
	{
		private $_userid;
		private $_keyboard;
		function __construct(){
			$this->_userid = addslashes($_POST["userid"]);
			$this->_keyboard = addslashes($_POST['userPassword']);
			$this->verify();
		}
		private function verify(){
			$sql = "SELECT * FROM users WHERE userId = '$this->_userid'";
			$db = new DB();
			$result = $db->query($sql);
			if($result){
				$row = $result->fetch_assoc();
				if($this->encrypt($this->_keyboard) == $row["keyboard"]){
					$_SESSION['username'] = $row['username'];
					echo "欢迎".$row['username']."登录!<br/>";
?>


					<script type='text/javascript'>
					function b(){  	//修改
					}
					var a = 5;
					document.write( a + "秒后跳转到主页")
					for(; a > 0;a--){	
					setInterval(function(){b()}, 1000);
				}
					window.open("../html/home.html",'_top');
					</script>
			


<?php
			exit();
			}
		}
				//echo "用户名或密码错误！";
?>


				<script type='text/javascript'>
				
				alert("密码错了哦");
				window.open("../html/login.html",'_top');
				</script>




<?php
		}
		private function encrypt($keyboard){
			return $keyboard;
		}
	}
 