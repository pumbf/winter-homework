<?php
	class  MessageBoard{
		

		function create($message, $videoname){
			$username = empty($_SESSION['username'])?'游客':$_SESSION['username'];//发言人身份
			$time = date("Y-m-d H:i:s");		//发言时间
			$db = new DB();
			$sql = "INSERT INTO messageboard(videoname,username,time,text) VALUES ('$videoname','$username','$time','$message')";		//创建发言
			$db->query($sql);
		}

		function addSupport($id){
			$SQL = new SQL('messageboard', 'id', $id);
			$sql = $SQL->select();
			$db = new DB();
			$result = $db->query($sql);
			$value = $result->fetch_assoc();
			$support = $value['support'];
			echo $support;
			$support++;
			echo $support;
			$sql = "UPDATE messageboard SET support='$support' WHERE id='$id'";
			$db->query($sql);
		}
		function display($videoname){
			$SQL = new SQL('messageboard','videoname',$videoname);
			$sql = $SQL->select();
			return $sql;
		}
	}