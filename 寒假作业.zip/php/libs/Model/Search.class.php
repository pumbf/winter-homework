<?php
/**
 * 搜索调用
 */
	class Search{
		function getsql($table, $field, $value, $request){
			$SQL = new SQL($table, $field, $value);
			$sql = $SQL->search();
			if(empty($request)){
				return $sql;
			}else{
				if(empty($field) && empty($value)){
					return $sql." WHERE variety='".$request."'";
				}else{
					return $sql." AND variety='".$request."'";
				}
			}
		}
	}