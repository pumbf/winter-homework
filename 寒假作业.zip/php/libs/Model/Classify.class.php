<?php
	/**
	* 上传视频分类，和图片归类
	*/
	class  Classify
	{
		private $_variety;             	//视频分类	
		private $_videoname;			//视频名字
		private $_picture;				//视频页面图地址
		private $_privider;				//视频上传者
		private $_formate;				//视频格式
		private $_address;				//视频存放地址
		private $_tmp_name;				//视频缓存地址
		private $_filenameExtention;	//视频后缀名
		private $_introduction;			//视频介绍
		private $_folder;				//文件夹地址
		private $id;        			//数据库id
		private $_time;					//上传时间

		function addVideo(){
			if(empty($_FILES['video'])){
				echo "上传视频失败，视频大于500M或其他错误";
				exit();
			}else{
				$video = $_FILES['video'];
				$error = $video['error'];
				if($error == 0){
					$this->putvalue($video);				//获取form表单的值
					$this->movefile();				//文件移到指定文件夹内
					$db = new DB();
					$sql = "INSERT INTO resource(id,variety,videoname,provider,format,address,introduction,time) VALUES('$this->id','$this->_variety','$this->_videoname','$this->_privider','$this->_formate','$this->_address','$this->_introduction','$this->_time')";           //将数据输入数据库中
					$result = $db->query($sql);
					if(!$result){
						echo "数据库传入失败";
					}
				}else{
					echo"error:$error";
				}
			}
			
		}
		private function putvalue($video){
			
			$this->_variety = addslashes($_POST['classify']);		//视频分类
			$this->_videoname = addslashes($_POST['videoname']);	//视频名字
			$this->_formate = $video['type'];				//视频格式
			$this->_tmp_name = $video['tmp_name'];	
			$name = explode('.', addslashes($video['name']));   		//按.分成数组，获取后缀名
			$key = count($name) - 1;        				//爆炸后的size,$size-1为后缀名的标示;
			$this->_filenameExtention = $name["$key"];		//获取后缀
			$this->_privider = $_SESSION['username'];		//上传者名字
			
			$id = $this->getMaxId();						//获取最大ID
			$this->id = $id;
			$this->_folder = "../video/".$id."/";     //文件夹的位置
			$this->_introduction = $this->text(addslashes($_POST['introduction']));
			$this->_time = date("Y-m-d H:i:s");
		}
		function getMaxId(){
			$db = new DB();
			$sql = "SELECT * FROM resource";
			$result = $db->query($sql);
			$value;
			foreach ($result as $key => $value1) {
				$value = $value1;
			}
			if(empty($value)){
				return 1;
			}else{
				return $value['id']+1;
			}

		}
		// function createTable(){
		// 	$db = new DB();						//连接数据库
		// 	//创建留言板表
		// 	$sql = "CREATE TABLE ".$this->_videoname."(				
		// 	id smallint(3) unsigned  NOT NULL AUTO_INCREMENT,
		// 	videoname varchar(30) NOT NULL,
  // 			username varchar(30) NOT NULL,
  // 			time datetime NOT NULL,
		// 	text VARCHAR(300) NOT NULL,
		// 	support smallint(3) unsigned  NOT NULL DEFAULT 0,
  // 			PRIMARY KEY (id))
  // 			ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1";
  // 			$db->query($sql);

			// "(
			// // id int(10) auto_increment PRIMARY KEY NOT NULL,
			// // time datetime(15), 
			// // username varchar(30) CHARACTER SET utf8,
			// // text varchar(301) CHARACTER SET utf8
			// )"
		//}
		private function movefile(){
			if(!file_exists($this->_folder)){
				mkdir($this->_folder);
			}
			$this->_address = $this->_folder.$this->_videoname.'.'.$this->_filenameExtention;
			$address = iconv('UTF-8','GB2312//IGNORE',$this->_address);//转成GB码
			move_uploaded_file($this->_tmp_name,$address);			//放置视频
	
		}
		
		private function text($str){
			$str = str_replace("\n","<br>",$str);		//
			return $str;
		}
		
		function addPicture(){
			if(!empty($_FILES['picture'])){
				$picture = $_FILES['picture'];
				$error = $picture['error'];
				if($error == 0){					//没有错误
					$tmp_name = $picture['tmp_name'];
					$name = explode('.', $picture['name']);
					$key = count($name) - 1; 		//获取最后的字符串
					$type = explode('/', $picture['type']);				//
					$address = $this->_folder.$type['0']."/";			//图片储存位置
					echo $address;
					if(!file_exists($address)){
						mkdir($address);
					}
					$address = $address."origin.".$name[$key];
					move_uploaded_file($tmp_name,$address);    //放置原图片
					$this->_picture =  $this->smallPicture($address, $type);     //缩小图片
					$db  = new DB();
					$sql = "UPDATE resource SET picture = '$this->_picture' WHERE id = '$this->id'";
					$result = $db->query($sql);
					if(!$result){
						echo "数据库操作失败";
					}
					
				}else{
					echo "error:".$error;			//错误报错
				}
			}
			
		}
		

		function smallPicture($address, $type){
				eval('$img = imagecreatefrom'.$type['1'].'($address);');
				$size = getimagesize($address);
				$picture = imagecreatetruecolor(160,100);
				imagecopyresampled($picture, $img, 0, 0, 0, 0, 160, 100, $size['0'], $size['1']);
				$address = str_replace("origin", "small", $address);
				eval("image".$type['1'].'($picture, $address);');
				return $address;

		}

	}