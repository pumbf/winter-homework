<?php
	echo $path = dirname(dirname(dirname(dirname(__FILE__))))."\video";
?>