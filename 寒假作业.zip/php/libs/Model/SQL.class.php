<?php
/**
 * 返回所需的sql语句；
 */

class SQL{
	private $_tablename;		//表名
	private $_field;			//相应栏位
	private $_value;			//栏位对应的值

	function __construct($table, $field, $value){
		$this->_tablename = addslashes($table);
		$this->_field = addslashes($field);
		$this->_value = addslashes($value);
		if(empty($this->_tablename)){
			return false;
		}
	}
	function select(){
		if(empty($this->_field) && empty($this->_value)){	//当两个为空时，无条件全部搜索
			return "SELECT * FROM ".$this->_tablename;
		}else{
			return "SELECT * FROM ".$this->_tablename." WHERE ".$this->_field."='".$this->_value."'";
		}
	}

	function update(){
		if(empty($this->_field) || empty($this->_value)){
			return false;
		}else{
			return "UPDATE ".$this->_tablename." SET ".$this->_field."=".$this->_value." WHERE ".$_POST['field1']."='".$_POST['value1']."'";
		}
	}
	function delete(){
		if(empty($this->_field) || empty($this->_value)){
			return false;
		}else{
			return "DELETE FROM ".$this->_tablename." WHERE ".$this->_field."='".$this->_value."'";
		}
	}
	function search(){
		if(empty($this->_field) || empty($this->_value)){	//当两个为空时，无条件全部搜索
			return "SELECT * FROM ".$this->_tablename;
		}else{
			return "SELECT * FROM ".$this->_tablename." WHERE ".$this->_field." LIKE '%".$this->_value."%'";
		}
	}
}