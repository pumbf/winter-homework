<?php 
	
	class Enroll{
		private $_userid;		
		private $_username;
		private $_keyboard;
/**
 * 注册信息
 */
		function __construct() {
			$this->_userid = addslashes($_POST['userid']);
			$this->_keyboard = $this->encrypt(addslashes($_POST['userPassword1']));
			$this->_username = addslashes($_POST['nameId']);
			$this->add_db();
		}
		private function add_db(){
			$a = $this->_username;
			$sql = "INSERT  INTO users(userId,keyboard,username) VALUES('$this->_userid','$this->_keyboard','$this->_username')";
			$db =  new DB();
			$result = $db->query($sql);
			if(!$result){
?>			<script type="text/javascript">   		//修改！！
				window.open("../html/login.html",'_top');
			</script>
<?php
			echo("数据库操作失败");

			}else{
				echo "注册成功";
				$_SESSION['username'] = $this->_username;
			
?>			<script type="text/javascript">   		//修改！！
				window.open("../html/home.html",'_top');
			</script>
	<?php   }
		}
		private function encrypt($keyboard){
			return $keyboard;
		}
	}

	// header("content-type:text/html; charset = utf-8");
	// $username = addslashes($_POST['userid']);
	// $keyboard = addslashes($_POST['userPassword1']);
	// $A = new Enroll($username, $keyboard);
?>
