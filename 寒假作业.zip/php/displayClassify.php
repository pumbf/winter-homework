<?php
	require_once('function.php');
	require_once('libs/View/Display.class.php');
	$db = M('DB');
	$table = 'resource';
	$filed = 'variety';
	$value = $_GET['classify'];
	$SQL = new SQL($table, $filed, $value);
	$sql = $SQL->select();
	$Display = new Display();
	$Display->displayHomeClassify($sql);