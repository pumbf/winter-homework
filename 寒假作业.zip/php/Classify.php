<?php
	require_once('./function.php');
	$classify = M('Classify');
	$classify->addVideo();
	$classify->addPicture();
?>
<script type="text/javascript">
	window.open("../html/videoGuanLi.php","_top");
</script>