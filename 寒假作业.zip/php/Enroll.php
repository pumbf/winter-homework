<?php
	require_once("./libs/Model/DB.class.php");
	require_once("./function.php");
	$login = M("Enroll");