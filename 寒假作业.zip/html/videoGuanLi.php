<!DOCTYPE html>
<html>
<head>
	<meta charset=utf-8>
	<link rel="stylesheet" type="text/css" href="../css/videoGuanLi.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont1/iconfont.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont4/iconfont.css">
	<script src="../javascript/jquery.js"></script>
	<title>寒假学习</title>
</head>
<body>
	<div class="navigationBar">
		<div class="navigationBarLeft">
			<ul>
				<li class="master">
					<a href="home.html">
						<i class="iconfontTV">&#xe603;</i>
						<span>主站</span>
					</a>
				</li>
				<li class="master">
					<a href="draw.html">
						<span>画友</span>
					</a> 
				</li>
				<li class="master">
					<a href="game.html">
						<span>游戏中心</span>
						<i class="iconfontBETANEW">&#xe72b;</i>
					</a>
				</li>
				<li class="master">
					<a href="broadcast.html">
						<span>直播</span>
					</a>
				</li>
				<li class="master">
					<a href="products.html">
						<span>周边</span>
					</a>
				</li>
				<li class="master">
					<a href="japan.html">
						<span>日本游</span>
						<i class="iconfontBETANEW">&#xe64d;</i>
					</a>
				</li>
			</ul>
		</div>
		<div class="navigationBarRight">
			<ul>
				<li class="contribution">
					<a href="contribution.php">
						<span style="color:white;">投稿</span>
					</a>
				</li>
				<li class="EL">
					<a href="enroll.html">
						<span>注册</span>
					</a>
				</li>
				<li class="EL">|</li>
				<li class="EL">
					<a href="login.html">
						<span>登录</span>
					</a>
				</li>
				<li class="ELOK">
					<a href="videoGuanLi.php">
						<div class="niCheng">昵称在这</div>
					</a>
					<ul class="logout">
						<li>退出</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<form id="manage">
		<div class="fontBox">
			<span class="font">视频管理</span>
		</div>
		<div class="box">
			<div class="frist_navigation">
				<div class="navigation1" id="shaiXuan">
					<em class="move1" style="display: block;">筛选条件</em>
					<ul class="second_navigation">
						<li class="navigation2">分区</li>
							<ul class="third_navigation">
								<li class="navigation3" id="dongHua" onclick="getVariety(this)">动画</li>
								<li class="navigation3" id="yinYue" onclick="getVariety(this)">音乐</li>
								<li class="navigation3" id="youXi" onclick="getVariety(this)">游戏</li>
								<li class="navigation3" id="yuLe" onclick="getVariety(this)">娱乐</li>
								<li class="navigation3" id="dianShiJu" onclick="getVariety(this)">电视剧</li>
								<li class="navigation3" id="fanJu" onclick="getVariety(this)">番剧</li>
								<li class="navigation3" id="dianYin" onclick="getVariety(this)">电影</li>
								<li class="navigation3" id="wuDao" onclick="getVariety(this)">舞蹈</li>
							</ul>
<!-- 						<li class="navigation2">状态</li>
 						<li class="navigation2">1123</li>
 						<li class="navigation2">2123</li>
 						<li class="navigation2">3123</li> -->
					</ul>
				</div>
<!-- 				<div class="navigation1" id="paiXu">
					<em>投稿排序</em>
				</div> -->
			</div>
			<div class="dis">
				<div id="display">&nbsp;</div>
				<div id="delete">&nbsp;</div>
			</div>
			<div class="edit_finish">
				<div id="edit">编辑</div>
				<div id="finish">完成</div>
			</div>
			<div class="html" id='displayVideo'>
				
			</div>
		</div>
	</form>
	<div class="header">
		<img src="../picture/13.jpg"  height="100%" width="100%" class="img_header">
	</div>
	
</body>
	<script type="text/javascript" src='../javascript/videoGuanLi.js'></script>
	<script type="text/javascript" src="../javascript/judgeLoginAndLogout.js"></script>
</html>