<!DOCTYPE html>
<html>
<head>
	<meta charset=utf-8>
	<link rel="stylesheet" type="text/css" href="../css/contribution.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont1/iconfont.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont3/iconfont.css">
	<script src="../javascript/jquery.js"></script>
	<title>寒假学习</title>
</head>
<body>
	<div class="navigationBar">
		<div class="navigationBarLeft">
			<ul>
				<li class="master">
					<a href="home.html">
						<i class="iconfontTV">&#xe603;</i>
						<span>主站</span>
					</a>
				</li>
				<li class="master">
					<a href="draw.html">
						<span>画友</span>
					</a> 
				</li>
				<li class="master">
					<a href="game.html">
						<span>游戏中心</span>
						<i class="iconfontBETANEW">&#xe72b;</i>
					</a>
				</li>
				<li class="master">
					<a href="broadcast.html">
						<span>直播</span>
					</a>
				</li>
				<li class="master">
					<a href="products.html">
						<span>周边</span>
					</a>
				</li>
				<li class="master">
					<a href="japan.html">
						<span>日本游</span>
						<i class="iconfontBETANEW">&#xe64d;</i>
					</a>
				</li>
			</ul>
		</div>
		<div class="navigationBarRight">
			<ul>
				<li class="contribution">
					<a href="contribution.php">
						<span style="color:white;">投稿</span>
					</a>
				</li>
				<li class="EL">
					<a href="enroll.html">
						<span>注册</span>
					</a>
				</li>
				<li class="EL">|</li>
				<li class="EL">
					<a href="login.html">
						<span>登录</span>
					</a>
				</li>
				<li class="ELOK">
					<a href="videoGuanLi.php">
						<div class="niCheng">昵称在这</div>
					</a>
					<ul class="logout">
						<li>退出</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<form enctype="multipart/form-data" id = "theFrom">
		<div class="up">
			<div id="upImg">
				<i class="iconfont" id="icon">&#xe64c;</i>
				<div class="upFont">点击上传封面</div>
				<input type="file" id="upFile" name = "picture" accept="image/gif,image/jpeg,image/png">
				<ul class="upUl">
					<li>与视频差异过大，或没有上传图片</li>
					<li>将自动截取影片画面</li>
					<li>建议480*300</li>
				</ul>
			</div>
			<div id="upVideo">
				<div class="upButton">
					<i class="iconfont" id="iconf">&#xe64c;</i>
					<en class="upWritten">视频上传</en>
				</div>
				<input type="file" id="FILE" name = "video" accept=".mp4">
				<input type="text" id="upText">
				<div id="upButton_error" class="error"></div>
				<div id="fenLei_error" class="error"></div>
				<div id="biaoTi_error" class="error"></div>
				<div id="jianJie_error" class="error"></div>
			</div>
			<div class="box">
				<div class="fenLei_biaoTi">
					<em style="font-size: 20px;">分区 : </em>
					<input type="text" class="fen_biao" id="fenLei" name = "classify" placeholder="正确的选择分区有利于投稿的通过 \(^o^)/YES!" readonly="readonly">
					<ul class="main_one">
						<li class="mainOne" id="dongHua">动画</li>
						<li class="mainOne" id="yinYue">音乐</li>
						<li class="mainOne" id="youXi">游戏</li>
						<li class="mainOne" id="yuLe">娱乐</li>
						<li class="mainOne" id="dianShiJu">电视剧</li>
						<li class="mainOne" id="fanJu">番剧</li>
						<li class="mainOne" id="dianYin">电影</li>
						<li class="mainOne" id="wuDao">舞蹈</li>
					</ul>
				</div>
				<div class="fenLei_biaoTi" style="margin-top: 20px;">
					<em style="font-size: 20px;">标题 : </em>
					<input type="text" class="fen_biao" id="biaoTi" name = "videoname" placeholder="请尽量使用中文，按在分区规范填写 (*＾-＾*)">
				</div>
				<div class="jian_jie">
					<em style="font-size: 20px;">简介 : </em>
					<textarea id="jianJie" name="introduction" ></textarea>
				</div>
			</div>
			<div id="upOK" onclick="function_up()">确认投稿</div>
		</div>
	</form>
	<div id="back">
		<img src="../picture/11.png" height="100%" width="100%">
	</div>
	<div class="background">
		<img src="../picture/12.jpg" height="100%" width="100%">
	</div>
	<script type="text/javascript" src='../javascript/contribution.js'></script>
<!-- 	<script type="text/javascript" src="../javascript/judgeLoginAndLogout.js"></script> -->
</body>
</html>