<!DOCTYPE html>
<html>
<head>
	<meta charset=utf-8>
	<link rel="stylesheet" type="text/css" href="../css/search.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont1/iconfont.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont5/iconfont.css">
	<script src="../javascript/jquery.js"></script>
	<title>寒假学习</title>
</head>
<body>
	<div class="navigationBar">
		<div class="navigationBarLeft">
			<ul>
				<li class="master">
					<a href="home.html">
						<i class="iconfontTV">&#xe603;</i>
						<span>主站</span>
					</a>
				</li>
				<li class="master">
					<a href="draw.html">
						<span>画友</span>
					</a> 
				</li>
				<li class="master">
					<a href="game.html">
						<span>游戏中心</span>
						<i class="iconfontBETANEW">&#xe72b;</i>
					</a>
				</li>
				<li class="master">
					<a href="broadcast.html">
						<span>直播</span>
					</a>
				</li>
				<li class="master">
					<a href="products.html">
						<span>周边</span>
					</a>
				</li>
				<li class="master">
					<a href="japan.html">
						<span>日本游</span>
						<i class="iconfontBETANEW">&#xe64d;</i>
					</a>
				</li>
			</ul>
		</div>
		<div class="navigationBarRight">
			<ul>
				<li class="contribution">
					<a href="contribution.php">
						<span style="color:white;">投稿</span>
					</a>
				</li>
				<li class="EL">
					<a href="enroll.html">
						<span>注册</span>
					</a>
				</li>
				<li class="EL">|</li>
				<li class="EL">
					<a href="login.html">
						<span>登录</span>
					</a>
				</li>
				<li class="ELOK">
					<a href="videoGuanLi.php">
						<div class="niCheng">昵称在这</div>
					</a>
				</li>
			</ul>
		</div>
	</div>
	<div class="horizontal">
		<div class="smallBox">
			<em><span class="font">搜索 | </span></em>
			<div class="input_search">
				<input type="text" name="searchId" class="searchBox" id='keyword'<?php $str = empty($_GET['keword'])?'':$_GET['keword']; echo "value = '$str'";?>>
				<input type="button" value="搜索" class="searchButton" id='search'>
			</div>
		</div>
	</div>
	<div class="fruit" id='displaySearch'>
		
	</div>
	<script type="text/javascript" src="../javascript/judgeLoginAndLogout.js"></script>
	<script type="text/javascript" src='../javascript/search.js'></script>
</body>
</html>