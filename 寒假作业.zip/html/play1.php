<!DOCTYPE html>
<html>
<head>
	<meta charset=utf-8>
	<link rel="stylesheet" type="text/css" href="../css/play.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont1/iconfont.css">
	<link rel="stylesheet" type="text/css" href="../iconfont/iconfont5/iconfont.css">
	<link href="../video-js/video-js.css" rel="stylesheet" type="text/css">
	<script src="../video-js/video.js"></script>
	<script>
    	_V_.options.flash.swf = "../video-js/video-js.swf";
 	</script>
	<script src="../javascript/jquery.js"></script>
	<title>寒假学习</title>
</head>
<body>
	<?php
		require_once("../php/function.php");
		require_once("../php/libs/Model/DB.class.php");
		require_once("../php/libs/Model/SQL.class.php");
		$db = M('DB');						//连接数据库
		$id = $_GET['videoid'];				//获取id值
		$SQL = new SQL('resource', 'id', $id);		//得到sql语句
		$sql = $SQL->select();		
		$result = $db->query($sql);				
		$data = $result->fetch_assoc();				//视频属性
		$name = $data['videoname'];					//视频内容
		$variety = $data['variety'];				//视频类别
		$picturePath = $data['picture'];			//图片地址
		$provider = $data['provider'];				//视频上传者
		$videoPath = $data['address'];				//视频地址
		$time = explode('.', $data['time'])['0'];	//上传时间
		$introduction = $data['introduction'];		//视频介绍

	?>
	<div class="navigationBar">
		<div class="navigationBarLeft">
			<ul>
				<li class="master">
					<a href="home.html">
						<i class="iconfontTV">&#xe603;</i>
						<span>主站</span>
					</a>
				</li>
				<li class="master">
					<a href="draw.html">
						<span>画友</span>
					</a> 
				</li>
				<li class="master">
					<a href="game.html">
						<span>游戏中心</span>
						<i class="iconfontBETANEW">&#xe72b;</i>
					</a>
				</li>
				<li class="master">
					<a href="broadcast.html">
						<span>直播</span>
					</a>
				</li>
				<li class="master">
					<a href="products.html">
						<span>周边</span>
					</a>
				</li>
				<li class="master">
					<a href="japan.html">
						<span>日本游</span>
						<i class="iconfontBETANEW">&#xe64d;</i>
					</a>
				</li>
			</ul>
		</div>
		<div class="navigationBarRight">
			<ul>
				<li class="contribution">
					<a href="contribution.php">
						<span style="color:white;">投稿</span>
					</a>
				</li>
				<li class="EL">
					<a href="enroll.html">
						<span>注册</span>
					</a>
				</li>
				<li class="EL">|</li>
				<li class="EL">
					<a href="login.html">
						<span>登录</span>
					</a>
				</li>
				<li class="ELOK">
					<a href="videoGuanLi.php">
						<div class="niCheng">昵称在这</div>
					</a>
					<ul class="logout">
						<li>退出</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<div class="navigationImg">
		<div class="bottomNavigation">
			<ul>
				<li class="navigation2">
					<div class="iconfont" id="icon1">&#xe631;</div>
					<span class="font">首页</span>
				</li>
				<li class="navigation2">
					<div class="iconfont" id="icon2">&#xe604;</div>
					<span class="font">动画</span>
				</li>
				<li class="navigation2">
					<div class="iconfont" id="icon3">&#xe651;</div>
					<span class="font">音乐</span>
				</li>
				<li class="navigation2">
					<div class="iconfont" id="icon4">&#xe6d8;</div>
					<span class="font">游戏</span>
				</li>
				<li class="navigation2">
					<div class="iconfont" id="icon5">&#xe636;</div>
					<span class="font">娱乐</span>
				</li>
				<li class="navigation2">
					<div class="iconfont" id="icon6">&#xe625;</div>
					<span class="font">电视</span>
				</li>
				<li class="navigation2">
					<div class="iconfont" id="icon7">&#xe63e;</div>
					<span class="font">番剧</span>
				</li>
				<li class="navigation2">
					<div class="iconfont" id="icon8">&#xe7e9;</div>
					<span class="font">电影</span>
				</li>
				<li class="navigation2">
					<div class="iconfont" id="icon9">&#xe65b;</div>
					<span class="font">舞蹈</span>
				</li>
			</ul>
		</div>
	</div>
	<div class="asd"><!-- 抵消img的poisition：relative -->
		<div style="float: left;">
			<input type="text" id='name' class="biao_ti"  placeholder="标题" readonly="readonly" <?php echo "value='$name'";?>>
			<br/><br/>
			<input type="text" class="type" placeholder="类别" readonly="readonly" <?php echo "value='$variety'";?>>
			<br/><br/>
			<input type="text" class="time" placeholder="时间" readonly="readonly" <?php echo "value='$time'";?>>
		</div>
		<textarea class="jian_jie" readonly="readonly"><?php echo $introduction;?></textarea>
		<input type="text" class="niCheng1"  placeholder="昵称" readonly="readonly" <?php echo "value='$provider'";?>>
		<div class="user_img"><?php echo"<img src='$picturePath' width=160 height=100>";?></div>
	</div>
	<div class="play">
		<div class="playBox">
			<video id="example_video_1" class="video-js vjs-default-skin" controls preload="none" width="700" height="600"   poster="http://video-js.zencoder.com/oceans-clip.png" data-setup="{}">
			
			
			<?php echo "<source src ='$videoPath' type='video/mp4' />";?>
				
			
    			
    			
    			<track kind="captions" src="../video-js/captions.vtt" srclang="en" label="English" />
  			</video>
		</div>
		<div class="dan_mu"></div>
	</div>
	<div class="bottom">
		<div class="user"></div>
		<div class="prompt">要登录才能恢复哦（笑）</div>
		<textarea class="message" id='text'></textarea>
		<div class="fa_biao" onclick="create()">发表<br/>评论</div>
	</div>
	<form id="pingLun">
		<div class="display"  id="answerBox">
			<div class="font_answer">评&nbsp;论</div>
			<div class="a"></div>
			<div class='answerBox'>
				<em><div class='ansewer_userId'>用户名</div></em>
				<div><textarea class='answer_content' autoHeight='ture' readonly='readonly'></textarea></div>
				<em><div class='answer_time'>评论时间</div></em>
				<div class='good'><span>赞</span><span class='number'>(&nbsp;)</span></div>
			</div>
		</div>
	</form>
	<script type="text/javascript" src='../javascript/play.js'></script>
</body>
</html>